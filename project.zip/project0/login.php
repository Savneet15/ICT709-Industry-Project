<?php 
include("connect.php"); 
session_start();
if(!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
include("header1.php"); 
}
else
{
include("header.php"); 
}
unset($_SESSION['id']);
?>
            <!-- /HEADER -->

            <!-- Content area -->
            <div class="content-area" style="padding-top: 100px;">
             <div id="main">
            <section class="page-section light featured-line xs-padding" style="padding-top: 50px;">
                    <div class="container" style="text-align: center;">
<div class="form-background" style="width: 400px;">

                    
                        <div class="form-header color">
                            <h1 class="section-title">
                                <span class="icon-inner"><span class="fa-stack"><i class="fa rhex fa-stack-2x"></i><i class="fa fa-ticket fa-stack-1x"></i></span></span>
                                <span class="title-inner">Login</span>
                            </h1>
                        </div>
                        <?php
                                if (isset($_POST['submit'])) {
                                
                                      function clean($str) {
                                        $str = @trim($str);
                                        if (get_magic_quotes_gpc()) {
                                            $str = stripslashes($str);
                                        }
                                        return mysql_real_escape_string($str);
                                    }
                                    $username = $_POST['username'];
                                    $password = $_POST['password'];
                                    

                                    $query = mysql_query("select * from staff where staff_username='$username' and staff_password='$password'") or die(mysql_error());
                                    $count = mysql_num_rows($query);
                                    $row = mysql_fetch_array($query);


                                    if ($count > 0) {
                                       
                                        $_SESSION['id'] = $row['staff_id'];
                                        echo "<script>window.location='profile.php';</script>";
                                        session_write_close();
                                    } else {
                                       session_write_close();
                                        ?>
                                        <div class="alert alert-danger" style="margin-top:10px;"><i class="icon-remove-sign"></i>&nbsp;Please Check Your Username And Password</div>
                                      
                                        <?php
                                    }
                                }
                                ?>
<form method="post" class="registration-form alt">
                            <div class="row">
                                <div class="col-sm-12 form-alert"></div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <input type="text" placeholder="User Name" name="username" data-toggle="tooltip" class="form-control input-name" data-original-title="Name is required">
                                    </div>
                                </div>
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <input type="password"  placeholder="Password"  name="password" data-toggle="tooltip" class="form-control input-password" data-original-title="Password">
                                    </div>
                                </div>                                  
                                <div class="col-sm-12">
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-theme btn-block submit-button" data-animation-delay="100" data-animation="flipInY" name="submit"> Log in <i class="fa fa-arrow-circle-right"></i></button>
                                    </div>
                                </div>
                            </div>
                        </form>  
                        </div>
                       
                        </div>
                        </section>
                    </div>

            </div>
            <!-- /Content area -->

            
   <!-- FOOTER -->
            <footer class="footer">
                <div class="footer-meta">
                    <div class="container text-center">
                       
                        <span class="copyright" data-animation="fadeInUp" data-animation-delay="100">&copy; 2018 ADTC Solutions.</span>
                    </div>
                </div>
            </footer>
            <!-- /FOOTER -->

            <div class="to-top" style="float: right;"><i class="fa fa-angle-up"></i></div>


        </div>
       
    
    <script src="assets/plugins/jquery/jquery-2.1.1.min.js"></script>
    <script src="assets/plugins/jquery-ui-1.11.4.custom/jquery-ui.min.js"></script>
    <script src="assets/plugins/modernizr.custom.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>
    <script src="assets/plugins/superfish/js/superfish.js"></script>
    <script src="assets/plugins/prettyphoto/js/jquery.prettyPhoto.js"></script>
    <script src="assets/plugins/placeholdem.min.js"></script>
    <script src="assets/plugins/jquery.smoothscroll.min.js"></script>
    <script src="assets/plugins/jquery.easing.min.js"></script>
    <script src="assets/plugins/smooth-scrollbar.min.js"></script>

    <!-- JS Page Level -->
    <script src="assets/plugins/owlcarousel2/owl.carousel.min.js"></script>
    <script src="assets/plugins/waypoints/waypoints.min.js"></script>
    <script src="assets/plugins/countdown/jquery.plugin.min.js"></script>
    <script src="assets/plugins/countdown/jquery.countdown.min.js"></script>
    <script src="assets/plugins/isotope/jquery.isotope.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>

    <!--<script src="assets/js/theme-ajax-mail.js"></script>-->
    <script src="assets/js/theme.js"></script>


  <script type="text/javascript">
        "use strict";
        jQuery(document).ready(function () {
            theme.init();
            theme.initMainSlider();
            theme.initCountDown();
            theme.initPartnerSlider();
            theme.initTestimonials();
            theme.initCorouselSlider4();
            theme.initCorouselSlider3();
            theme.initGoogleMap();
        });
        jQuery(window).load(function () {
            theme.initAnimation();
        });

        jQuery(window).load(function () {
            jQuery('body').scrollspy({offset: 100, target: '.navigation'});
        });
        jQuery(window).load(function () {
            jQuery('body').scrollspy('refresh');
        });
        jQuery(window).resize(function () {
            jQuery('body').scrollspy('refresh');
        });

        jQuery(document).ready(function () {
            theme.onResize();
        });
        jQuery(window).load(function () {
            theme.onResize();
        });
        jQuery(window).resize(function () {
            theme.onResize();
        });

        jQuery(window).load(function () {
            if (location.hash != '') {
                var hash = '#' + window.location.hash.substr(1);
                if (hash.length) {
                    jQuery('html,body').delay(0).animate({
                        scrollTop: jQuery(hash).offset().top - 44 + 'px'
                    }, {
                        duration: 1200,
                        easing: "easeInOutExpo"
                    });
                }
            }
        });

    </script>  

</body>


</html>
