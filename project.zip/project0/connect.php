<?php

error_reporting(0);
$connect = mysql_connect("localhost", "root", "");


mysql_select_db("project") or die(mysql_error());




?>