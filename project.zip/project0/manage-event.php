<?php
include('connect.php');
session_start(); 
if(!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
include("header1.php"); 
}
else
{
include("header.php"); 
}
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from staff where staff_id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);

?>


           

            <!-- Content area -->
            <div class="content-area" style="padding-top: 100px;">
             <div id="main">
            <section class="page-section light featured-line xs-padding" style="padding-top: 50px;">
                    <div class="container" style="text-align: center;">
<div class="form-background" style="width: 100%; min-height: 500px">

                    
                        <div class="form-header color">
                            <h1 class="section-title">
                                <span class="icon-inner"><span class="fa-stack"><i class="fa rhex fa-stack-2x"></i><i class="fa fa-ticket fa-stack-1x"></i></span></span>
                                <span class="title-inner">Events</span>
                            </h1>
                        </div>
                        <table class="table table-bordered table-striped mb-none" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
									<thead>
										<tr>
                                       		<th>Name </th>
                                            <th>Description</th>
                                       		<th>Location </th>
											<th>Date </th>
											<th>Start Time </th>
											<th>End Time </th>
											
                                           </tr>
											
									</thead>
									<tbody>
                                    <?php
                                    $query = mysql_query("select * from events") or die(mysql_error());
                                    while ($row = mysql_fetch_array($query)) {
                                        $id = $row['event_id'];
										
                                        ?>
										<tr>
											<td><?php echo $row['event_name']; ?></td>
                                            <td><?php echo $row['event_description']; ?></td>
											<td><?php echo $row['event_location']; ?></td>
                                            <td><?php echo $row['event_date']; ?></td>
                                            <td><?php echo $row['event_start_time']; ?></td>
                                            <td><?php echo $row['event_end_time']; ?></td>
											
                                         
 
                                            
										</tr>
                                       
                                        <?php } ?>
                                        </tbody>
                                        </table>

                        </div>
                       
                        </div>
                        </section>
                    </div>

            </div>
            <!-- /Content area -->

            
   <!-- FOOTER -->
            <footer class="footer">
                <div class="footer-meta">
                    <div class="container text-center">
                       
                        <span class="copyright" data-animation="fadeInUp" data-animation-delay="100">&copy; 2018 ADTC Solutions.</span>
                    </div>
                </div>
            </footer>
            <!-- /FOOTER -->

            <div class="to-top" style="float: right;"><i class="fa fa-angle-up"></i></div>


        </div>
       
    
    <script src="assets/plugins/jquery/jquery-2.1.1.min.js"></script>
    <script src="assets/plugins/jquery-ui-1.11.4.custom/jquery-ui.min.js"></script>
    <script src="assets/plugins/modernizr.custom.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>
    <script src="assets/plugins/superfish/js/superfish.js"></script>
    <script src="assets/plugins/prettyphoto/js/jquery.prettyPhoto.js"></script>
    <script src="assets/plugins/placeholdem.min.js"></script>
    <script src="assets/plugins/jquery.smoothscroll.min.js"></script>
    <script src="assets/plugins/jquery.easing.min.js"></script>
    <script src="assets/plugins/smooth-scrollbar.min.js"></script>

    <!-- JS Page Level -->
    <script src="assets/plugins/owlcarousel2/owl.carousel.min.js"></script>
    <script src="assets/plugins/waypoints/waypoints.min.js"></script>
    <script src="assets/plugins/countdown/jquery.plugin.min.js"></script>
    <script src="assets/plugins/countdown/jquery.countdown.min.js"></script>
    <script src="assets/plugins/isotope/jquery.isotope.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>

    <!--<script src="assets/js/theme-ajax-mail.js"></script>-->
    <script src="assets/js/theme.js"></script>


  <script type="text/javascript">
        "use strict";
        jQuery(document).ready(function () {
            theme.init();
            theme.initMainSlider();
            theme.initCountDown();
            theme.initPartnerSlider();
            theme.initTestimonials();
            theme.initCorouselSlider4();
            theme.initCorouselSlider3();
            theme.initGoogleMap();
        });
        jQuery(window).load(function () {
            theme.initAnimation();
        });

        jQuery(window).load(function () {
            jQuery('body').scrollspy({offset: 100, target: '.navigation'});
        });
        jQuery(window).load(function () {
            jQuery('body').scrollspy('refresh');
        });
        jQuery(window).resize(function () {
            jQuery('body').scrollspy('refresh');
        });

        jQuery(document).ready(function () {
            theme.onResize();
        });
        jQuery(window).load(function () {
            theme.onResize();
        });
        jQuery(window).resize(function () {
            theme.onResize();
        });

        jQuery(window).load(function () {
            if (location.hash != '') {
                var hash = '#' + window.location.hash.substr(1);
                if (hash.length) {
                    jQuery('html,body').delay(0).animate({
                        scrollTop: jQuery(hash).offset().top - 44 + 'px'
                    }, {
                        duration: 1200,
                        easing: "easeInOutExpo"
                    });
                }
            }
        });

    </script>  

</body>


</html>
