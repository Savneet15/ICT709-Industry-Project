<?php
include('../connect.php');
include('session.php'); 
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from admin where id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);
?>


			<!-- start: header -->
			<?php include("header.php"); ?>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include("nav.php"); ?>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Add Event </h2>
					
						
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-12">
                        <?php
								
                            if (isset($_POST['submit'])) {
								$name = $_POST['name'];
								$description = $_POST['description'];
								$location = $_POST['location'];
                                $date = $_POST['date'];
								$stime = $_POST['stime'];
								$etime = $_POST['etime'];
								
								

                                $query2=mysql_query("insert into events (event_name,event_description,event_location, event_date, event_start_time, event_end_time)
                            	values ('$name','$description','$location','$date','$stime','$etime')") or die(mysql_error());

                                 if($query2 == 'success')
{
	
echo'<div class="alert alert-success"><b>Event has been created Successfully.</div>';
echo "<script>window.location='manage-event.php';</script>";
}
                               else
							   {echo'<div class="alert alert-warning"><b>Please try again.</div>';
								   }
                            }
                            ?>
							<form id="form"  class="form-horizontal" method="post" enctype="multipart/form-data">
								<section class="panel">
									<header class="panel-heading">
											<h2 class="panel-title">Add Event </h2>
									</header>
									<div class="panel-body">
                                    <div class="form-group">
												<label class="col-md-3 control-label">Event Name : <span class="required">*</span></label>
												<div class="col-md-6">
												
												<input type="text" name="name" class="form-control" placeholder="Name of Event" required/>
											
												</div>
											</div>
                                    	 <div class="form-group">
												<label class="col-md-3 control-label">Event Description : <span class="required">*</span></label>
												<div class="col-md-6">
												
												<textarea type="text" name="description" class="form-control" placeholder="Enter Event Description" required/></textarea>
											
												</div>
											</div>
										<div class="form-group">
												<label class="col-md-3 control-label">Event Location : <span class="required">*</span></label>
												<div class="col-md-6">
												
												<input type="text" name="location" class="form-control" placeholder="Location of Event" required/>
											
												</div>
											</div>
                                        <div class="form-group">
											<label class="col-md-3 control-label">Event date : <span class="required">*</span></label>
												<div class="col-md-4">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
														<input type="text" data-plugin-datepicker="bottom" data-date-format="yyyy-mm-dd" class="form-control" name="date">
													</div>
												</div>
											</div>
                                            <div class="form-group">
												<label class="col-md-3 control-label">Event Start Time : <span class="required">*</span></label>
												<div class="col-md-4">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
												<input type="text" data-plugin-timepicker="bottom" class="form-control" name="stime" required="required">
												</div>

											</div>
											</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Event End Time : <span class="required">*</span></label>
											<div class="col-md-4">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
												<input type="text" data-plugin-timepicker="bottom" class="form-control" name="etime" required="required">
												</div>

											</div>
										</div>
                                                                              
                                       

										
									</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-info" name="submit" type="submit">Submit</button>
												<button type="reset" class="btn btn-warning">Reset</button>
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
						</div>
							<!-- end: page -->
				</section>
			</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Calender</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
							</div>
			
							
						</div>
					</div>
				</div>
			</aside>
		</section>
<?php include("footer.php"); ?>