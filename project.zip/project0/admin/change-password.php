<?php
include('../connect.php');
include('session.php');
include('function.php'); 
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from admin where id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);
$id=$_GET['id'];
?>


			<!-- start: header -->
			<?php include("header.php"); ?>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include("nav.php"); ?>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Change Password</h2>
					
						
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
                        
						<?php
                            if (isset($_POST['submit'])) {

								 $current = $row1['password'];
								 $password = md5($_POST['npassword']);
								 $current1 = md5($_POST['password']);
								
								
                                if($current == $current1)
                            {
                               $query1 = mysql_query("update admin set password='$password' where id='$userid'") or die(mysql_error());
if($query1 == 'success')
{
echo'<div class="alert alert-success"><b>Your Password has been updated Successfully.</div>';
echo "<script>window.location='profile.php';</script>";
}
                               else
							   {echo'<div class="alert alert-warning"><b>Please try again.</div>';
								   }
                            }else
							{
								echo '<script> 
								alert("Your current password is not correct !!");
							document.getElementById("pass").focus();
							 </script>';
								}
							}
                            ?>  
                           
							<form id="form"  class="form-horizontal" method="post" enctype="multipart/form-data">
								 <section class="panel">
									<header class="panel-heading">
											<h2 class="panel-title">Change Password</h2>
									</header>
									<div class="panel-body">
												<div class="form-group">
													<label class="col-md-3 control-label">Old Password</label>
													<div class="col-md-8">
														<input type="password" class="form-control" name="password" id="pass">
													</div>
												</div>
												<div class="form-group">
													<label class="col-md-3 control-label">New Password</label>
													<div class="col-md-8">
														<input type="password" class="form-control" name="npassword" id="newpass">
													</div>
												</div>
												<div class="form-group">
													<label class="col-md-3 control-label">Repeat New Password</label>
													<div class="col-md-8">
														<input type="password" class="form-control" name="cpassword" id="rpass">
													</div>
												</div>
											
											</div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
														<button type="submit" class="btn btn-info" name="submit">Submit</button>
													</div>
										</div>
									</footer>
								</section>
									
							</form>
						</div>
						
						</div>
							<!-- end: page -->
				</section>
			</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Calender</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
							</div>
			
							
						</div>
					</div>
				</div>
			</aside>
		</section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>		
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>		
		<script src="assets/vendor/jquery-cookie/jquery-cookie.js"></script>		
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>		
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>		
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>		
		<script src="assets/vendor/magnific-popup/jquery.magnific-popup.js"></script>		
		<script src="assets/vendor/jquery-placeholder/jquery-placeholder.js"></script>
        <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
		
		<!-- Specific Page Vendor -->		
		<script src="assets/vendor/jquery-validation/jquery.validate.js"></script>		
		<script src="assets/vendor/select2/js/select2.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>
		<!-- Analytics to Track Preview Website -->		
	</body>


</html>