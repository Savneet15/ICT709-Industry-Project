<?php
include('../connect.php');
include('session.php');
$get_id=$_GET['id'];

mysql_query("delete from events where event_id='$get_id'")or die(mysql_error());
header('location:manage-event.php');
?>
