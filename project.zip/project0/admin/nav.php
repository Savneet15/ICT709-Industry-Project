<aside id="sidebar-left" class="sidebar-left">
				
					<div class="sidebar-header">
						<div class="sidebar-title">
							Navigation
						</div>
						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle">
							<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
						</div>
					</div>
				
					<div class="nano">
						<div class="nano-content">
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-main">
									<li class="nav">
										<a href="dashboard.php">
											<i class="fa fa-home" aria-hidden="true"></i>
											<span>Dashboard</span>
										</a>
									</li>
									<li class="nav-parent">
										<a>
											<i class="fa fa-columns" aria-hidden="true"></i>
											<span>Events</span>
										</a>
										<ul class="nav nav-children">
											<li>
												<a href="add-event.php">
													 Add Event
												</a>
											</li>
											
											<li>
												<a href="manage-event.php">
													Manage Events
												</a>
											</li>
                                           
                                            </ul>
										
									</li>
                                    <li class="nav-parent">
										<a>
											<i class="fa fa-columns" aria-hidden="true"></i>
											<span>Staff</span>
										</a>
										<ul class="nav nav-children">
											<li>
												<a href="add-staff.php">
													 Add Staff
												</a>
											</li>
											
											<li>
												<a href="manage-staff.php">
													Manage Staff
												</a>
											</li>
                                           
                                            </ul>
										
									</li>
									<li class="nav-parent">
										<a>
											<i class="fa fa-columns" aria-hidden="true"></i>
											<span>Profile</span>
										</a>
										<ul class="nav nav-children">
											<li>
												<a href="profile.php">
													 Profile
												</a>
											</li>
											<li>
												<a href="edit-profile.php">
													 Edit Profile
												</a>
											</li>
											
											<li>
												<a href="change-password.php">
													Change Password
												</a>
											</li>
                                           
                                            </ul>
										
									</li>
								</ul>
							</nav>
				
							<hr class="separator" />
					</div>
				
					</div>
				
				</aside>