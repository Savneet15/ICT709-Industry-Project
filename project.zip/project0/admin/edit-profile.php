<?php
include('../connect.php');
include('session.php'); 
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from admin where id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);

?>


			<!-- start: header -->
			<?php include("header.php"); ?>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include("nav.php"); ?>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Edit Profile</h2>
					
						
					</header>

					<!-- start: page -->

					<div class="row">
						
						<div class="col-md-8 col-lg-9">

							<div class="tabs">
								<ul class="nav nav-tabs tabs-primary">
									<li class="active">
										<a href="#overview" data-toggle="tab">Overview</a>
									</li>
									
								</ul>
								<div class="tab-content">
									<div id="overview" class="tab-pane active">
                                    <?php
                            if (isset($_POST['submit'])) {

								 
                                $fname = $_POST['fname'];
								$lname = $_POST['lname'];
								$username = $_POST['username'];
								$email = $_POST['email'];
                               
								

                                $query2=mysql_query("update admin set fname='$fname', lname='$lname', username='$username', email='$email' where id='$userid' ") or die(mysql_error());

                                if($query2 == 'success')
{
echo'<div class="alert alert-success"><b>Your Profile has been updated Successfully.</div>';
echo "<script>window.location='profile.php';</script>";
}
                               else
							   {echo'<div class="alert alert-warning"><b>Please try again.</div>';
								   }
                            }
                            ?>
                                    
										<form id="form" class="form-horizontal" method="post" enctype="multipart/form-data">
											<h4 class="mb-xlg">Personal Information</h4>
											
												<div class="form-group">
													<label class="col-md-3 control-label">First Name</label>
													<div class="col-md-8">
														<input type="text" class="form-control" name="fname" 
                                                        value="<?php echo $row1['fname']; ?>">
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Last Name</label>
													<div class="col-md-8">
														<input type="text" class="form-control" name="lname" value="<?php echo $row1['lname']; ?>">
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Username</label>
													<div class="col-md-8">
														<input type="text" class="form-control" name="username" value="<?php echo $row1['username']; ?>">
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Email</label>
													<div class="col-md-8">
														<input type="text" class="form-control" name="email" value="<?php echo $row1['email']; ?>">
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Account Type</label>
													<div class="col-md-8">
														<input type="text" class="form-control" name="user" value="<?php echo $row1['user']; ?>" disabled>
													</div>
												</div>
                                                
                                                
                                                
											</div>
                                            <div class="panel-footer">
												<div class="row">
													<div class="col-md-9 col-md-offset-3">
														<button type="submit" class="btn btn-info" name="submit">Submit</button>
														
													</div>
												</div>
											</div>
												
											
                                            

										</form>

										
									</div>
									
								</div>
							</div>
						</div>
						

					</div>
					<!-- end: page -->
				</section>
			</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Calender</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
							</div>
			
							
			
						</div>
					</div>
				</div>
			</aside>
		</section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>		
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>		
		<script src="assets/vendor/jquery-cookie/jquery-cookie.js"></script>		
				
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>		
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>		
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>		
		<script src="assets/vendor/magnific-popup/jquery.magnific-popup.js"></script>		
		<script src="assets/vendor/jquery-placeholder/jquery-placeholder.js"></script>
        <script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
		
		<!-- Specific Page Vendor -->		
		<script src="assets/vendor/autosize/autosize.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>
		<!-- Analytics to Track Preview Website -->		
	</body>


</html>