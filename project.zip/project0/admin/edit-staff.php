<?php
include('../connect.php');
include('session.php'); 
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from admin where id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);
$id=$_GET['id'];
?>


			<!-- start: header -->
			<?php include("header.php"); ?>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include("nav.php"); ?>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Edit Staff </h2>
					
						
					</header>

					<!-- start: page -->
					<div class="row">
						<div class="col-md-10">
                        <?php
						
                            $query = mysql_query("select * from staff where staff_id = '$id'") or die(mysql_error());
                            $row = mysql_fetch_array($query);
                        ?>
						<?php
                            if (isset($_POST['submit'])) {

								$fname = $_POST['fname'];
								$lname = $_POST['lname'];
								$email = $_POST['email'];
								$user = $_POST['user'];
                                $pass = $_POST['pass'];
								$phone = $_POST['phone'];
								$dob = $_POST['dob'];
								

                               $query2 = mysql_query("update staff set staff_fname='$fname', staff_lname='$lname', staff_email='$email', staff_username='$user', staff_password='$pass', staff_mobile='$phone', staff_dob='$dob' where staff_id='$id' ") or die(mysql_error());

                                if($query2 == 'success')
{
echo'<div class="alert alert-success"><b>Staff Member has been updated Successfully.</div>';
echo "<script>window.location='manage-staff.php';</script>";
}
                               else
							   {echo'<div class="alert alert-warning"><b>Please try again.</div>';
								   }
                            }
                            ?>
							<form id="form"  class="form-horizontal" method="post" enctype="multipart/form-data">
								<section class="panel">
									<header class="panel-heading">
											<h2 class="panel-title">Edit Staff </h2>
									</header>
									<div class="panel-body">
                                    <div class="form-group">
											<label class="col-sm-3 control-label">First Name : <span class="required">*</span></label>
											<div class="col-md-6">
												
												<input type="text" name="fname" class="form-control" value="<?php echo $row['staff_fname']; ?>" required/>
											
												</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Last Name : <span class="required">*</span></label>
											<div class="col-md-6">
												
												<input type="text" name="lname" class="form-control" value="<?php echo $row['staff_lname']; ?>" required/>
											
												</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Email : <span class="required">*</span></label>
											<div class="col-md-6">
												
												<input type="email" name="email" class="form-control" value="<?php echo $row['staff_email']; ?>" required/>
											
												</div>
										</div>
                                       <div class="form-group">
											<label class="col-sm-3 control-label">Username : <span class="required">*</span></label>
											<div class="col-md-6">
												
												<input type="text" name="user" class="form-control" value="<?php echo $row['staff_username']; ?>" required/>
											
												</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Password : <span class="required">*</span></label>
											<div class="col-md-6">
												
												<input type="text" name="pass" class="form-control" value="<?php echo $row['staff_password']; ?>" required/>
											
												</div>
										</div>
										<div class="form-group">
											<label class="col-sm-3 control-label">Mobile Number : <span class="required">*</span></label>
											<div class="col-md-6">
												
												<input type="text" name="phone" class="form-control" value="<?php echo $row['staff_mobile']; ?>" required/>
											
												</div>
										</div>
                                    	
                                        <div class="form-group">
												<label class="col-md-3 control-label">Birth Date : <span class="required">*</span></label>
												<div class="col-md-6">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="fa fa-calendar"></i>
														</span>
														<input type="text" data-plugin-datepicker data-date-format="yyyy-mm-dd" class="form-control" name="dob" value="<?php echo $row['staff_dob']; ?>">
													</div>
												</div>
										</div>
                                       
                                       
                                    </div>
									<footer class="panel-footer">
										<div class="row">
											<div class="col-sm-9 col-sm-offset-3">
												<button class="btn btn-info" name="submit" type="submit">Submit</button>
												<button type="reset" class="btn btn-warning">Reset</button>
											</div>
										</div>
									</footer>
								</section>
							</form>
						</div>
						
						</div>
							<!-- end: page -->
				</section>
			</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Calender</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
							</div>
			
							
						</div>
					</div>
				</div>
			</aside>
		</section>
<?php include("footer.php"); ?>