<?php
include('../connect.php');
include('session.php'); 
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from admin where id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);
$id=$_GET['id'];
?>


			<!-- start: header -->
			<?php include("header.php"); ?>
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include("nav.php"); ?>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>My Profile</h2>
					
						
					</header>

					<!-- start: page -->

					<div class="row">
						
						<div class="col-md-8 col-lg-9">

							<div class="tabs">
								<ul class="nav nav-tabs tabs-primary">
									<li class="active">
										<a href="#overview" data-toggle="tab">Overview</a>
									</li>
									
								</ul>
								<div class="tab-content">
									<div id="overview" class="tab-pane active">
                                    
										<form class="form-horizontal">
											<h4 class="mb-xlg">Personal Information</h4>
											
												<div class="form-group">
													<label class="col-md-3 control-label">First Name</label>
													<div class="col-md-8">
														<label class="col-md-3 control-label" style="text-align: left;"><?php echo $row1['fname']; ?></label>
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Last Name</label>
													<div class="col-md-8">
														<label class="col-md-3 control-label" style="text-align: left;"><?php echo $row1['lname']; ?></label>
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Username</label>
													<div class="col-md-8">
														<label class="col-md-3 control-label" style="text-align: left;"><?php echo $row1['username']; ?></label>
													</div>
												</div>
                                                 <div class="form-group">
													<label class="col-md-3 control-label">Email</label>
													<div class="col-md-8">
														<label class="col-md-3 control-label" style="text-align: left;"><?php echo $row1['email']; ?></label>
													</div>
												</div>
                                                <div class="form-group">
													<label class="col-md-3 control-label">Account Type</label>
													<div class="col-md-8">
														<label class="col-md-3 control-label" style="text-align: left;"><?php echo $row1['user']; ?></label>
													</div>
												</div>
												
											
                                            

										</form>

										
									</div>
									
								</div>
							</div>
						</div>
						

					</div>
					<!-- end: page -->
				</section>
			</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Calender</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
							
							</div>
			
							
			
						</div>
					</div>
				</div>
			</aside>
		</section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>		
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>		
		<script src="assets/vendor/jquery-cookie/jquery-cookie.js"></script>		
				
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>		
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>		
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>		
		<script src="assets/vendor/magnific-popup/jquery.magnific-popup.js"></script>		
		<script src="assets/vendor/jquery-placeholder/jquery-placeholder.js"></script>
		
		<!-- Specific Page Vendor -->		
		<script src="assets/vendor/autosize/autosize.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>
		<!-- Analytics to Track Preview Website -->		
	</body>


</html>