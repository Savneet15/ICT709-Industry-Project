<?php
include("../connect.php");
include("session.php");
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from admin where id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);
?>


			<!-- start: header -->
            <?php include("header.php"); ?>
			
			<!-- end: header -->

			<div class="inner-wrapper">
				<!-- start: sidebar -->
				<?php include("nav.php"); ?>
				<!-- end: sidebar -->

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Dashboard</h2>
					
						
					</header>

					<section class="panel">
							<header class="panel-heading">
												
								<h2 class="panel-title">Manage Events </h2>
								<a href="add-event.php" class="btn btn-success" style="float: right;" >Add Event</a>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-tabletools" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
									<thead>
										<tr>
                                       		<th>Name </th>
                                            <th>Description</th>
                                       		<th>Location </th>
											<th>Date </th>
											<th>Start Time </th>
											<th>End Time </th>
											<th>Action </th>
                                           </tr>
											
									</thead>
									<tbody>
                                    <?php
                                    $query = mysql_query("select * from events") or die(mysql_error());
                                    while ($row = mysql_fetch_array($query)) {
                                        $id = $row['event_id'];
										
                                        ?>
										<tr>
											<td><?php echo $row['event_name']; ?></td>
                                            <td><?php echo $row['event_description']; ?></td>
											<td><?php echo $row['event_location']; ?></td>
                                            <td><?php echo $row['event_date']; ?></td>
                                            <td><?php echo $row['event_start_time']; ?></td>
                                            <td><?php echo $row['event_end_time']; ?></td>
											
											<td>
                                            <a href="edit-event.php<?php echo '?id=' . $id; ?>" class="btn btn-xs btn-info" ><i class="fa fa-pencil"></i></a>
                                            <a href="#a<?php echo $id; ?>" class="modal-basic btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>

									
                                                                                       
                                            </td>
                                           <div id="a<?php echo $id; ?>" class="modal-block modal-full-color modal-block-danger mfp-hide">
										<section class="panel">
											<header class="panel-heading">
												<h2 class="panel-title">Delete Event!</h2>
											</header>
											<div class="panel-body">
												<div class="modal-wrapper">
													<div class="modal-icon">
														<i class="fa fa-warning"></i>
													</div>
													<div class="modal-text">
														<h4>Warning</h4>
														<p>Are you sure you want to Delete Event <?php echo $row['event_name']; ?>?</p>
													</div>
												</div>
											</div>
											<footer class="panel-footer">
												<div class="row">
													<div class="col-md-12 text-right">
                                                    <a class="btn btn-primary" href="delete-event.php<?php echo '?id=' . $id; ?>">Confirm</a>
                                                     <button class="btn btn-default modal-dismiss">Cancel</button>
													</div>
												</div>
											</footer>
										</section>
									</div>
 
                                            
										</tr>
                                       
                                        <?php } ?>
                                        </tbody>
                                        </table>
										
										</div>
										
									
								</section>

								<section class="panel">
							<header class="panel-heading">
												
								<h2 class="panel-title">Manage Staff </h2>
								<a href="add-staff.php" class="btn btn-success" style="float: right;" >Add Staff</a>
							</header>
							<div class="panel-body">
								<table class="table table-bordered table-striped mb-none" id="datatable-tabletools1" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
									<thead>
										<tr>
                                       		<th>First Name </th>
                                            <th>Last Name</th>
                                       		<th>Email </th>
											<th>Username </th>
											<th>Mobile Number </th>
											<th>Birth Date </th>
											<th>Action </th>
                                           </tr>
											
									</thead>
									<tbody>
                                    <?php
                                    $query = mysql_query("select * from Staff") or die(mysql_error());
                                    while ($row = mysql_fetch_array($query)) {
                                        $id = $row['staff_id'];
										
                                        ?>
										<tr>
											<td><?php echo $row['staff_fname']; ?></td>
                                            <td><?php echo $row['staff_lname']; ?></td>
											<td><?php echo $row['staff_email']; ?></td>
                                            <td><?php echo $row['staff_username']; ?></td>
                                            <td><?php echo $row['staff_mobile']; ?></td>
                                            <td><?php echo $row['staff_dob']; ?></td>
											
											<td>
                                            <a href="edit-staff.php<?php echo '?id=' . $id; ?>" class="btn btn-xs btn-info" ><i class="fa fa-pencil"></i></a>
                                            <a href="#a<?php echo $id; ?>" class="modal-basic btn btn-xs btn-danger"><i class="fa fa-trash"></i></a>

									
                                                                                       
                                            </td>
                                           <div id="a<?php echo $id; ?>" class="modal-block modal-full-color modal-block-danger mfp-hide">
										<section class="panel">
											<header class="panel-heading">
												<h2 class="panel-title">Delete Staff!</h2>
											</header>
											<div class="panel-body">
												<div class="modal-wrapper">
													<div class="modal-icon">
														<i class="fa fa-warning"></i>
													</div>
													<div class="modal-text">
														<h4>Warning</h4>
														<p>Are you sure you want to Delete Staff <?php echo $row['staff_fname']; ?> <?php echo $row['staff_lname']; ?>?</p>
													</div>
												</div>
											</div>
											<footer class="panel-footer">
												<div class="row">
													<div class="col-md-12 text-right">
                                                    <a class="btn btn-primary" href="delete-staff.php<?php echo '?id=' . $id; ?>">Confirm</a>
                                                     <button class="btn btn-default modal-dismiss">Cancel</button>
													</div>
												</div>
											</footer>
										</section>
									</div>
 
                                            
										</tr>
                                       
                                        <?php } ?>
                                        </tbody>
                                        </table>
										
										</div>
										
									
								</section>
					
										
					
				
					<!-- end: page -->
				</section>
			</div>

			<aside id="sidebar-right" class="sidebar-right">
				<div class="nano">
					<div class="nano-content">
						<a href="#" class="mobile-close visible-xs">
							Collapse <i class="fa fa-chevron-right"></i>
						</a>
			
						<div class="sidebar-right-wrapper">
			
							<div class="sidebar-widget widget-calendar">
								<h6>Calender</h6>
								<div data-plugin-datepicker data-plugin-skin="dark" ></div>
			
							</div>
			
						
						</div>
					</div>
				</div>
			</aside>
		</section>

		<?php include("footer.php"); ?>