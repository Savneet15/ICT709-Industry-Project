<?php
include('connect.php');
session_start(); 
if(!isset($_SESSION['id']) || (trim($_SESSION['id']) == '')) {
include("header1.php"); 
}
else
{
include("header.php");
}
$userid = $_SESSION['id'];
$query1 = mysql_query("select * from staff where staff_id = '$userid'") or die(mysql_error());
$row1 = mysql_fetch_array($query1);
$id=$_GET['id'];
$current = $row1['staff_password'];
 
?>


           

            <!-- Content area -->
            <div class="content-area" style="padding-top: 100px;">
             <div id="main">
            <section class="page-section light featured-line xs-padding" style="padding-top: 50px;">
                    <div class="container" style="text-align: center;">
<div class="form-background" style="width: 100%">

                    
                        <div class="form-header color">
                            <h1 class="section-title">
                                <span class="icon-inner"><span class="fa-stack"><i class="fa rhex fa-stack-2x"></i><i class="fa fa-ticket fa-stack-1x"></i></span></span>
                                <span class="title-inner">Change Password</span>
                            </h1>
                        </div>
                        <?php
                            if (isset($_POST['submit'])) {

                                 
                                 $password = $_POST['npassword'];
                                 $current1 = $_POST['password'];
                                
                                
                                if($current == $current1)
                            {
                               $query1 = mysql_query("update staff set staff_password='$password' where staff_id='$userid'") or die(mysql_error());
if($query1 == 'success')
{
echo'<div class="alert alert-success"><b>Your Password has been updated Successfully.</div>';
echo '<script>alert("Password has been changed Successfully.");  </script>';

echo "<script>window.location='profile.php';</script>";
}
                               else
                               {echo'<div class="alert alert-warning"><b>Please try again.</div>';
                                   }
                            }else
                            {
                                echo '<script> 
                                alert("Your current password is not correct !!");
                            document.getElementById("pass").focus();
                             </script>';
                                }
                            }
                            ?> 
<form id="form"  class="form-horizontal" method="post" enctype="multipart/form-data">
                                 
                                    <div class="panel-body">
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Old Password</label>
                                                    <div class="col-md-8">
                                                        <input type="password" class="form-control" name="password" id="pass">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">New Password</label>
                                                    <div class="col-md-8">
                                                        <input type="password" class="form-control" name="npassword" id="newpass">
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-3 control-label">Repeat New Password</label>
                                                    <div class="col-md-8">
                                                        <input type="password" class="form-control" name="cpassword" id="rpass">
                                                    </div>
                                                </div>
                                              <div class="col-sm-12">
                                    <div class="text-center">
                                        <button type="submit" class="btn btn-theme btn-block submit-button" data-animation-delay="100" data-animation="flipInY" name="submit">Submit <i class="fa fa-arrow-circle-right"></i></button>
                                    </div>
                                </div>    
                                            </div>
                                    
                                </section>
                                    
                            </form>  
                        </div>
                       
                        </div>
                       
                    </div>

            </div>
            <!-- /Content area -->

            
   <!-- FOOTER -->
            <footer class="footer">
                <div class="footer-meta">
                    <div class="container text-center">
                       
                        <span class="copyright" data-animation="fadeInUp" data-animation-delay="100">&copy; 2018 ADTC Solutions.</span>
                    </div>
                </div>
            </footer>
            <!-- /FOOTER -->

            <div class="to-top" style="float: right;"><i class="fa fa-angle-up"></i></div>


        </div>
       
    
    <script src="assets/plugins/jquery/jquery-2.1.1.min.js"></script>
    <script src="assets/plugins/jquery-ui-1.11.4.custom/jquery-ui.min.js"></script>
    <script src="assets/plugins/modernizr.custom.js"></script>
    <script src="assets/plugins/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/plugins/bootstrap-select/bootstrap-select.min.js"></script>
    <script src="assets/plugins/superfish/js/superfish.js"></script>
    <script src="assets/plugins/prettyphoto/js/jquery.prettyPhoto.js"></script>
    <script src="assets/plugins/placeholdem.min.js"></script>
    <script src="assets/plugins/jquery.smoothscroll.min.js"></script>
    <script src="assets/plugins/jquery.easing.min.js"></script>
    <script src="assets/plugins/smooth-scrollbar.min.js"></script>

    <!-- JS Page Level -->
    <script src="assets/plugins/owlcarousel2/owl.carousel.min.js"></script>
    <script src="assets/plugins/waypoints/waypoints.min.js"></script>
    <script src="assets/plugins/countdown/jquery.plugin.min.js"></script>
    <script src="assets/plugins/countdown/jquery.countdown.min.js"></script>
    <script src="assets/plugins/isotope/jquery.isotope.min.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?v=3.exp&amp;sensor=false"></script>

    <!--<script src="assets/js/theme-ajax-mail.js"></script>-->
    <script src="assets/js/theme.js"></script>


  <script type="text/javascript">
        "use strict";
        jQuery(document).ready(function () {
            theme.init();
            theme.initMainSlider();
            theme.initCountDown();
            theme.initPartnerSlider();
            theme.initTestimonials();
            theme.initCorouselSlider4();
            theme.initCorouselSlider3();
            theme.initGoogleMap();
        });
        jQuery(window).load(function () {
            theme.initAnimation();
        });

        jQuery(window).load(function () {
            jQuery('body').scrollspy({offset: 100, target: '.navigation'});
        });
        jQuery(window).load(function () {
            jQuery('body').scrollspy('refresh');
        });
        jQuery(window).resize(function () {
            jQuery('body').scrollspy('refresh');
        });

        jQuery(document).ready(function () {
            theme.onResize();
        });
        jQuery(window).load(function () {
            theme.onResize();
        });
        jQuery(window).resize(function () {
            theme.onResize();
        });

        jQuery(window).load(function () {
            if (location.hash != '') {
                var hash = '#' + window.location.hash.substr(1);
                if (hash.length) {
                    jQuery('html,body').delay(0).animate({
                        scrollTop: jQuery(hash).offset().top - 44 + 'px'
                    }, {
                        duration: 1200,
                        easing: "easeInOutExpo"
                    });
                }
            }
        });

    </script>  

</body>


</html>
